#!/bin/bash

# korvaa tämä omalla käyttäjätunnuksellasi
USERNAME="marklaak"
# korvaa tämä haluamallasi kansion nimellä
PROJECT_FOLDER="ystavapalvelu"
# sovelluksesi tulee sijaitsemaan osoitteessa USERNAME.users.cs.helsinki.fi/PROJECT_FOLDER
